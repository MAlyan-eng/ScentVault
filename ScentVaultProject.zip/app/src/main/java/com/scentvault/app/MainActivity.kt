package com.scentvault.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF171613)
private val Panel = Color(0xFF24221D)
private val Gold = Color(0xFFD7B56D)
private val Cream = Color(0xFFF4EBDD)
private val Muted = Color(0xFFB7AE9D)

data class Perfume(val name: String, val brand: String, val family: String, val longevity: String, val projection: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ScentVaultApp() }
    }
}

@Composable
fun ScentVaultApp() {
    var tab by remember { mutableStateOf("Vault") }
    var showAdd by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var brand by remember { mutableStateOf("") }
    var family by remember { mutableStateOf("Woody") }
    var perfumes by remember { mutableStateOf(listOf(
        Perfume("Amber Royale", "ScentVault Sample", "Amber · Spicy", "8 hours", "Strong"),
        Perfume("Citrus No. 04", "ScentVault Sample", "Fresh · Citrus", "5 hours", "Moderate"),
        Perfume("Velvet Oud", "ScentVault Sample", "Woody · Oud", "10 hours", "Strong")
    )) }

    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Ink, surface = Panel, onPrimary = Ink, onBackground = Cream, onSurface = Cream, secondary = Muted)) {
        Scaffold(containerColor = Ink, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Home", "Vault", "Journal", "Insights").forEach { item ->
                    NavigationBarItem(selected = tab == item, onClick = { tab = item },
                        icon = { Text(when(item) { "Home" -> "⌂"; "Vault" -> "◇"; "Journal" -> "◷"; else -> "✧" }, fontSize = 20.sp) },
                        label = { Text(item) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Gold, selectedTextColor = Gold, indicatorColor = Ink, unselectedIconColor = Muted, unselectedTextColor = Muted))
                }
            }
        }, floatingActionButton = {
            if (tab == "Vault") FloatingActionButton(onClick = { showAdd = true }, containerColor = Gold, contentColor = Ink) { Text("+", fontSize = 28.sp) }
        }) { padding ->
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(top = 22.dp, bottom = 28.dp)) {
                item {
                    Text("SCENTVAULT", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(when(tab) { "Home" -> "Your scent,\\nyour signature."; "Journal" -> "Wear it.\\nRemember it."; "Insights" -> "Know your\\ncollection."; else -> "Your private\\nfragrance vault." }, color = Cream, fontSize = 32.sp, lineHeight = 37.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    Text("A considered collection of scents.", color = Muted, fontSize = 14.sp)
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        StatCard("IN YOUR VAULT", perfumes.size.toString(), Modifier.weight(1f))
                        StatCard("SCENT FAMILIES", perfumes.map { it.family }.distinct().size.toString(), Modifier.weight(1f))
                    }
                }
                item { Text(if (tab == "Journal") "RECENT WEAR" else if (tab == "Insights") "COLLECTION PROFILE" else "YOUR COLLECTION", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp) }
                items(perfumes) { p ->
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.fillMaxWidth().padding(17.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(52.dp, 64.dp).background(Color(0xFF393126), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Text("✦", color = Gold, fontSize = 25.sp) }
                                Spacer(Modifier.width(14.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(p.name, color = Cream, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                                    Text(p.brand, color = Muted, fontSize = 12.sp)
                                    Spacer(Modifier.height(8.dp))
                                    Text(p.family.uppercase(), color = Gold, fontSize = 10.sp, letterSpacing = 1.sp)
                                }
                            }
                            Spacer(Modifier.height(14.dp)); HorizontalDivider(color = Color(0xFF413C31)); Spacer(Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("Longevity  ${p.longevity}", color = Muted, fontSize = 12.sp)
                                Text("Projection  ${p.projection}", color = Muted, fontSize = 12.sp)
                            }
                        }
                    }
                }
                item {
                    Text("THE SCENT NOTE", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("Track what you love. Discover what suits you. Build a collection with intention.", color = Muted, fontSize = 14.sp, lineHeight = 21.sp)
                }
            }
        }
    }
    if (showAdd) AlertDialog(onDismissRequest = { showAdd = false }, containerColor = Panel, title = { Text("Add a fragrance", color = Cream) },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Perfume name") }, singleLine = true)
            OutlinedTextField(value = brand, onValueChange = { brand = it }, label = { Text("Brand") }, singleLine = true)
            Text("Scent family", color = Muted)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) { listOf("Woody", "Fresh", "Amber").forEach { FilterChip(selected = family == it, onClick = { family = it }, label = { Text(it) }) } }
        } },
        confirmButton = { TextButton(onClick = { if (name.isNotBlank()) { perfumes = listOf(Perfume(name.trim(), brand.ifBlank { "Unknown brand" }, family, "Not rated", "Not rated")) + perfumes; name = ""; brand = ""; family = "Woody"; showAdd = false } }) { Text("Add to vault", color = Gold) } },
        dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancel", color = Muted) } })
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(15.dp)) { Text(label, color = Muted, fontSize = 9.sp, letterSpacing = 1.sp); Spacer(Modifier.height(8.dp)); Text(value, color = Gold, fontSize = 28.sp, fontWeight = FontWeight.SemiBold) }
    }
}
